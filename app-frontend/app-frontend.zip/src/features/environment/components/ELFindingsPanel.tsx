import { EL_FINDINGS } from "@/features/environment/data/mockData";

export default function ELFindingsPanel() {
    return (
        <div className="flex-1 overflow-auto">
            <div
                className="flex flex-shrink-0 items-center gap-2 bg-[var(--color-hex-0a0a0a)] px-4 py-2"
                style={{
                    borderBottom: "1px solid var(--color-hex-141414)",
                }}
            >
                <span className="text-[8px] tracking-[0.18em] text-[var(--color-hex-444444)]">
                    EL FINDINGS CROSS-REFERENCE
                </span>
                <span className="ml-[8px] text-[8px] text-[var(--color-hex-555555)]">
                    confirmed findings linked to EL evidence artifacts
                </span>
            </div>
            <table className="w-full border-collapse text-[10.5px]">
                <thead>
                    <tr className="sticky top-0 bg-[var(--color-hex-0f0f0f)]">
                        {[
                            "FINDING",
                            "TYPE",
                            "TARGET",
                            "E_ORD",
                            "LINKED VDG NODE",
                            "EVIDENCE ARTIFACTS",
                        ].map((h) => (
                            <th
                                key={h}
                                className="px-[12px] py-[6px] text-left text-[8px] font-semibold tracking-[0.16em] whitespace-nowrap text-[var(--color-hex-444444)]"
                                style={{
                                    borderBottom: "1px solid var(--color-hex-1a1a1a)",
                                }}
                            >
                                {h}
                            </th>
                        ))}
                    </tr>
                </thead>
                <tbody>
                    {EL_FINDINGS.map((f, i) => (
                        <tr
                            key={f.id}
                            style={{
                                borderBottom: "1px solid var(--color-hex-111111)",
                                background: i % 2 ? "var(--color-hex-0b0b0b)" : "transparent",
                            }}
                            onMouseEnter={(e) =>
                                (e.currentTarget.style.background = "var(--color-hex-0f0f0f)")
                            }
                            onMouseLeave={(e) =>
                                (e.currentTarget.style.background =
                                    i % 2 ? "var(--color-hex-0b0b0b)" : "transparent")
                            }
                        >
                            <td className="px-[12px] py-[7px] text-[9px] font-bold text-[var(--color-hex-e31b23)]">
                                {f.id}
                            </td>
                            <td className="px-[12px] py-[7px] text-[var(--color-hex-a0a0a0)]">
                                {f.type}
                            </td>
                            <td className="px-[12px] py-[7px] text-[9px] text-[var(--color-hex-555555)]">
                                {f.target}
                            </td>
                            <td className="px-[12px] py-[7px] text-[var(--color-hex-666666)]">
                                {f.eord}/5
                            </td>
                            <td className="px-[12px] py-[7px] text-[9px] font-bold text-[var(--color-hex-e31b23)]">
                                {f.vdgNode}
                            </td>
                            <td className="px-[12px] py-[7px]">
                                <div className="flex flex-wrap gap-1">
                                    {f.evidence.map((e) => (
                                        <span
                                            key={e}
                                            className="rounded-[2px] border-[1px] border-solid border-[var(--color-hex-1e1e1e)] bg-[var(--color-hex-111111)] px-[5px] py-[1px] text-[7.5px] tracking-[0.08em] text-[var(--color-hex-444444)]"
                                        >
                                            {e}
                                        </span>
                                    ))}
                                </div>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
}
