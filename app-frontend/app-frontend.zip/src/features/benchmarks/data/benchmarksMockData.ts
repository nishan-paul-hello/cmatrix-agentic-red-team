import { BENCHMARK_STATUS, type BenchmarkStatus } from "@/types/domain-types";

export interface Bench {
    id: string;
    name: string;
    type: "CVE-BENCH" | "PREDIQL" | "MHBENCH";
    tasks: number;
    solved: number;
    partial: number;
    score: number;
    avgCost: string;
    avgTime: string;
    date: string;
    status: BenchmarkStatus;
}
export const BENCHMARKS: Bench[] = [
    {
        id: "B-041",
        name: "CVE-BENCH v2 Full",
        type: "CVE-BENCH",
        tasks: 50,
        solved: 38,
        partial: 6,
        score: 0.812,
        avgCost: "$0.184",
        avgTime: "18m",
        date: "Today",
        status: BENCHMARK_STATUS.COMPLETE,
    },
    {
        id: "B-038",
        name: "PrediQL Reasoning",
        type: "PREDIQL",
        tasks: 30,
        solved: 21,
        partial: 4,
        score: 0.741,
        avgCost: "$0.091",
        avgTime: "9m",
        date: "Yesterday",
        status: BENCHMARK_STATUS.COMPLETE,
    },
    {
        id: "B-035",
        name: "MH-Bench Multi-Host",
        type: "MHBENCH",
        tasks: 20,
        solved: 11,
        partial: 3,
        score: 0.622,
        avgCost: "$0.321",
        avgTime: "34m",
        date: "2d ago",
        status: BENCHMARK_STATUS.COMPLETE,
    },
    {
        id: "B-033",
        name: "CVE-BENCH v2 Fast",
        type: "CVE-BENCH",
        tasks: 20,
        solved: 16,
        partial: 2,
        score: 0.848,
        avgCost: "$0.072",
        avgTime: "11m",
        date: "3d ago",
        status: BENCHMARK_STATUS.COMPLETE,
    },
    {
        id: "B-042",
        name: "CVE-BENCH v2 Nightly",
        type: "CVE-BENCH",
        tasks: 50,
        solved: 0,
        partial: 3,
        score: 0,
        avgCost: "—",
        avgTime: "—",
        date: "Running",
        status: BENCHMARK_STATUS.RUNNING,
    },
    {
        id: "B-043",
        name: "PrediQL v2 Beta",
        type: "PREDIQL",
        tasks: 40,
        solved: 0,
        partial: 0,
        score: 0,
        avgCost: "—",
        avgTime: "—",
        date: "Queued",
        status: BENCHMARK_STATUS.QUEUED,
    },
];
export const TYPE_C: Record<Bench["type"], string> = {
    "CVE-BENCH": "var(--color-hex-e31b23)",
    PREDIQL: "var(--color-hex-d29922)",
    MHBENCH: "var(--color-hex-3fb950)",
};
export type Task = (typeof TASK_DATA)[0];
export const TASK_DATA = [
    {
        id: "T-001",
        name: "CVE-2024-1234 SQLi",
        category: "SQL INJECTION",
        solved: true,
        partial: false,
        cost: "$0.082",
        time: "14m",
        eord: 5,
        attempts: 2,
    },
    {
        id: "T-002",
        name: "CVE-2024-5678 AuthBypass",
        category: "AUTH",
        solved: true,
        partial: false,
        cost: "$0.054",
        time: "9m",
        eord: 5,
        attempts: 1,
    },
    {
        id: "T-003",
        name: "CVE-2024-9012 RCE",
        category: "RCE",
        solved: false,
        partial: true,
        cost: "$0.211",
        time: "22m",
        eord: 3,
        attempts: 3,
    },
    {
        id: "T-004",
        name: "CVE-2024-3456 IDOR",
        category: "ACCESS CTRL",
        solved: true,
        partial: false,
        cost: "$0.021",
        time: "5m",
        eord: 4,
        attempts: 1,
    },
    {
        id: "T-005",
        name: "CVE-2024-7890 XSS",
        category: "XSS",
        solved: true,
        partial: false,
        cost: "$0.031",
        time: "6m",
        eord: 5,
        attempts: 1,
    },
    {
        id: "T-006",
        name: "CVE-2024-2468 SSRF",
        category: "SSRF",
        solved: false,
        partial: false,
        cost: "$0.148",
        time: "18m",
        eord: 1,
        attempts: 3,
    },
    {
        id: "T-007",
        name: "CVE-2024-1357 XXE",
        category: "XXE",
        solved: true,
        partial: false,
        cost: "$0.061",
        time: "11m",
        eord: 4,
        attempts: 2,
    },
    {
        id: "T-008",
        name: "CVE-2024-8024 PathTrv",
        category: "PATH TRAVERSAL",
        solved: true,
        partial: false,
        cost: "$0.018",
        time: "4m",
        eord: 5,
        attempts: 1,
    },
];

/* ── screen 40: BENCHMARK DETAIL ── */
